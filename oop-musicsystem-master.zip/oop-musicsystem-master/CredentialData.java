package finals;

public final class CredentialData {
	public static String username;
	public static String password;
	public static String firstname;
	public static String lastname;
}
