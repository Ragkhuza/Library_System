package finals;

public class Run {	
	public static void main(String args[]) {
		Login.showWindow();
	}
}
